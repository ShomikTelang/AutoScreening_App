package com.example.rochestormanorscreening;



import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Time;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_SPEECH_INPUT = 1000;

    private TextToSpeech mTTS;
    //private EditText mEditText;
    //private SeekBar mSeekBarPitch;
    // private SeekBar mSeekBarSpeed;
    private Button mEnter;
    private Button mExit;
    //private Button mSupervisor;
    private TextView text;
    private TextView mResult;
    private Button mTemperature;
    private EditText mName;
    private EditText mTemp;
    private Timer timer = new Timer();
    private final long DELAY = 1000;
    int counterEnter = 0;
    int counterExit = 0;
    int counterChronic = 0;
    int person = 0;
    int personleave = 0;
    int personCondition = 0;
    int key = 0;
    String date = java.text.DateFormat.getDateTimeInstance().format(new Date());
//    String contEnter = "\r\n" + "[" + date + "] " + " " + x + " ENTERING:";



    //TextView mTextTv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
        }


        mEnter = findViewById(R.id.entering);
        mExit = findViewById(R.id.exiting);
        mResult = findViewById(R.id.result);
        mResult.setVisibility(View.INVISIBLE);
        //mResult.setVisibility(View.VISIBLE);
        mTemperature = findViewById(R.id.temperature);
        mTemperature.setVisibility(View.INVISIBLE);
        mName = findViewById(R.id.name);
        mName.setVisibility(View.INVISIBLE);
        mTemp = findViewById(R.id.temp);
       // mName.setVisibility(View.VISIBLE);
        mTemp.setVisibility(View.INVISIBLE);
//        mSupervisor=findViewById(R.id.supervisor);
//        //mSupervisor.setVisibility(View.VISIBLE);


        mTTS = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = mTTS.setLanguage(Locale.US);

                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported");
                    } else {
                        mEnter.setEnabled(true);
                        mExit.setEnabled(true);
                    }
                } else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });







//
//        mSupervisor.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                mName.setVisibility(View.VISIBLE);
//                mName.setHint("Enter Screener Name");
//                mSupervisor.setVisibility(View.INVISIBLE);
//                String word = "Screener, please type your name.";
//                text.setText(word);
//                mTTS.speak(word, TextToSpeech.QUEUE_FLUSH, null);
//
//                mName.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//
//                    public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
//                        if (actionId == EditorInfo.IME_ACTION_DONE) {
//                           // String date = java.text.DateFormat.getDateTimeInstance().format(new Date());
//                            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "RochesterManorScreening.txt");
//                            try {
//                                FileWriter fileWriter = new FileWriter(file, true);
//                                String breaker = "\r\n" + "----------------------------------------------------------------------------------------------------------------";
//                                String key = "\r\n" + "KEY FOR QUESTIONS:";
//                                String questions =  "\r\n" + "1. Do you have a sore throat, cough, runny nose, or symptoms of a fever?"
//                                        + "\r\n" + "2. Do you have shortness of breath, chest tightness, or body aches?" + "\r\n" + "3. Do you have diarrhea, nausea, vomiting, or loss of taste and smell?"
//                                        + "\r\n" + "4. Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?";
//                                String cont = "\r\n" + "\r\n" + "SCREENER: " + mName.getText().toString();
//                                fileWriter.append(breaker);
//                                fileWriter.append(key);
//                                fileWriter.append(questions);
//                                fileWriter.append(cont);
//                                fileWriter.append(breaker);
//                                fileWriter.close();
//                                Log.i("name", cont);
//                            } catch (FileNotFoundException e) {
//                                e.printStackTrace();
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//                            mName.setVisibility(View.INVISIBLE);
//                            mName.getText().clear();
//                            Handler handler = new Handler();
//                            handler.postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    mResult.setVisibility(View.INVISIBLE);
//                                    text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
//                                    mEnter.setVisibility(View.VISIBLE);
//                                    mExit.setVisibility(View.VISIBLE);
//                                }
//                            }, 2000);
//
//
//                        }
//                        return false;
//                    }
//                });
//
//
//            }
//        });


//        mSupervisor.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                mName.setVisibility(View.VISIBLE);
//                mName.setHint("Enter Name");
//                mSupervisor.setVisibility(View.INVISIBLE);
//                String word = "Supervisor, please type your name.";
//                text.setText(word);
//                mTTS.speak(word, TextToSpeech.QUEUE_FLUSH, null);
//                mName.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//
//                    public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
//                        if (actionId == EditorInfo.IME_ACTION_DONE) {
//                            try {
//                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "RochesterManorScreening.txt");
//                                FileWriter fileWriter = new FileWriter(file, true);
//                                String cont = "\r\n" + "SUPERVISOR: " + mName.getText().toString() ;
//                                fileWriter.append(cont);
//                                fileWriter.close();
//                                Log.i("name", cont);
//                            } catch (FileNotFoundException e) {
//                                e.printStackTrace();
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//                        }
//                        return false;
//
//
//            }
//        });

//        mEditText = findViewById(R.id.edit_text);
//        mSeekBarPitch = findViewById(R.id.seek_bar_pitch);
//        mSeekBarSpeed = findViewById(R.id.seek_bar_speed);
        text = findViewById(R.id.shomtext);
        mEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTemp.getText().clear();
                if(key == 0) {
                    File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Passed.txt");
                    try {
                        FileWriter fileWriter = new FileWriter(file, true);
                        String breaker = "\r\n" + "----------------------------------------------------------------------------------------------------------------";
                        String keyEnter = "\r\n" + "KEY FOR ENTERING QUESTIONS:";
                        String keyExit = "\r\n" + "KEY FOR EXITING QUESTIONS:";
                        String questionsEnter = "\r\n" + "1. Do you have a sore throat, cough, runny nose, or symptoms of a fever?"
                                + "\r\n" + "2. Do you have shortness of breath, chest tightness, or body aches?" + "\r\n" + "3. Do you have diarrhea, nausea, vomiting, or loss of taste and smell?"
                                + "\r\n" + "4. Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?" + "\r\n" + "5. Have you worked in facilities or offices with recognized COVID-19 cases?" +
                                "\r\n" + "IF YES - 6. Did you have greater than 10 minutes of contact with a person with confirmed COVID-19?" + "\r\n" + "IF YES - 7. Were you wearing recommended personal protective equipment?";
                        String questionsExit = "\r\n" + "1. Have you developed any symptoms that were referenced upon entry?";
                        // String cont = "\r\n" + "\r\n" + "SCREENER: " + mName.getText().toString();
                        //fileWriter.append(cont);
                        fileWriter.append(breaker);
                        fileWriter.append(keyEnter);
                        fileWriter.append(questionsEnter);
                        fileWriter.append(breaker);
                        fileWriter.append(keyExit);
                        fileWriter.append(questionsExit);
                        fileWriter.append(breaker);
                        fileWriter.close();
                        //Log.i("name", cont);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    File file2 = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                    try {
                        FileWriter fileWriter = new FileWriter(file2, true);
                        String breaker = "\r\n" + "----------------------------------------------------------------------------------------------------------------";
                        String keyEnter = "\r\n" + "KEY FOR ENTERING QUESTIONS:";
                        String keyExit = "\r\n" + "KEY FOR EXITING QUESTIONS:";
                        String questionsEnter = "\r\n" + "1. Do you have a sore throat, cough, runny nose, or symptoms of a fever?"
                                + "\r\n" + "2. Do you have shortness of breath, chest tightness, or body aches?" + "\r\n" + "3. Do you have diarrhea, nausea, vomiting, or loss of taste and smell?"
                                + "\r\n" + "4. Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?" + "\r\n" + "5. Have you worked in facilities or offices with recognized COVID-19 cases?" +
                                "\r\n" + "IF YES - 6. Did you have greater than 10 minutes of contact with a person with confirmed COVID-19?" + "\r\n" + "IF YES - 7. Were you wearing recommended personal protective equipment?";
                        String questionsExit = "\r\n" + "1. Have you developed any symptoms that were referenced upon entry?";
                        // String cont = "\r\n" + "\r\n" + "SCREENER: " + mName.getText().toString();
                        //fileWriter.append(cont);
                        fileWriter.append(breaker);
                        fileWriter.append(keyEnter);
                        fileWriter.append(questionsEnter);
                        fileWriter.append(breaker);
                        fileWriter.append(keyExit);
                        fileWriter.append(questionsExit);
                        fileWriter.append(breaker);
                        fileWriter.close();
                        //Log.i("name", cont);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                person = 1;
                key += 1;
                personleave = 0;
                //mSupervisor.setVisibility(View.INVISIBLE);
                mName.setVisibility(View.VISIBLE);
//                mTemp.setVisibility(View.VISIBLE);
                mName.setHint("Enter Name");
                mEnter.setVisibility(View.INVISIBLE);
                mExit.setVisibility(View.INVISIBLE);
                speak();
                counterEnter = 0;
                mName.setOnEditorActionListener(new TextView.OnEditorActionListener() {

                    public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                        if (actionId == EditorInfo.IME_ACTION_DONE) {
                            String date = java.text.DateFormat.getDateTimeInstance().format(new Date());

//                            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "RochesterManorScreening.txt");

//                            try {
//                                FileWriter fileWriter = new FileWriter(file, true);
//                                String cont = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
//                                fileWriter.append(cont);
//                                fileWriter.close();
//                                Log.i("name", cont);
//                            } catch (FileNotFoundException e) {
//                                e.printStackTrace();
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }


                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    mName.setVisibility(View.INVISIBLE);
                                    String weird = "Do you have a fever, sore throat, cough, or a runny nose?";
                                    // String weird = "Have you used the hand rub or worn the latex gloves?";
                                    text.setText(weird);
                                    Handler handler2 = new Handler();
                                    handler2.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
//                                            mTTS.speak("Have you used the hand rub or worn the latex gloves?", TextToSpeech.QUEUE_FLUSH, null);
                                            mTTS.speak("Do you have a fever, sore throat, cough, or a runny nose?", TextToSpeech.QUEUE_FLUSH, null);
                                        }
                                    }, 0);

                                    Log.i("value", "how are you");
                                    Handler handler1 = new Handler();
                                    handler1.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            shom();
                                        }
                                    }, 2700);


                                }
                            }, 1500);

                        }
                        return false;
                    }
                });

                Log.e("value", "hello");

                mTemperature.setVisibility(View.INVISIBLE);
                mResult.setVisibility(View.INVISIBLE);


            }
        });
        mExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTemp.getText().clear();
                if(key == 0) {
                    File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                    try {
                        FileWriter fileWriter = new FileWriter(file, true);
                        String breaker = "\r\n" + "----------------------------------------------------------------------------------------------------------------";
                        String keyEnter = "\r\n" + "KEY FOR ENTERING QUESTIONS:";
                        String keyExit = "\r\n" + "KEY FOR EXITING QUESTIONS:";
                        String questionsEnter = "\r\n" + "1. Do you have a sore throat, cough, runny nose, or symptoms of a fever?"
                                + "\r\n" + "2. Do you have shortness of breath, chest tightness, or body aches?" + "\r\n" + "3. Do you have diarrhea, nausea, vomiting, or loss of taste and smell?"
                                + "\r\n" + "4. Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?" + "\r\n" + "5. Have you worked in facilities or offices with recognized COVID-19 cases?" +
                                "\r\n" + "IF YES - 6. Did you have greater than 10 minutes of contact with a person with confirmed COVID-19?" + "\r\n" + "IF YES - 7. Were you wearing recommended personal protective equipment?";
                        String questionsExit = "\r\n" + "1. Have you developed any symptoms that were referenced upon entry?";
                        // String cont = "\r\n" + "\r\n" + "SCREENER: " + mName.getText().toString();
                        //fileWriter.append(cont);
                        fileWriter.append(breaker);
                        fileWriter.append(keyEnter);
                        fileWriter.append(questionsEnter);
                        fileWriter.append(breaker);
                        fileWriter.append(keyExit);
                        fileWriter.append(questionsExit);
                        fileWriter.append(breaker);
                        fileWriter.close();
                        //Log.i("name", cont);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    File file2 = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Passed.txt");
                    try {
                        FileWriter fileWriter = new FileWriter(file2, true);
                        String breaker = "\r\n" + "----------------------------------------------------------------------------------------------------------------";
                        String keyEnter = "\r\n" + "KEY FOR ENTERING QUESTIONS:";
                        String keyExit = "\r\n" + "KEY FOR EXITING QUESTIONS:";
                        String questionsEnter = "\r\n" + "1. Do you have a sore throat, cough, runny nose, or symptoms of a fever?"
                                + "\r\n" + "2. Do you have shortness of breath, chest tightness, or body aches?" + "\r\n" + "3. Do you have diarrhea, nausea, vomiting, or loss of taste and smell?"
                                + "\r\n" + "4. Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?" + "\r\n" + "5. Have you worked in facilities or offices with recognized COVID-19 cases?" +
                                "\r\n" + "IF YES - 6. Did you have greater than 10 minutes of contact with a person with confirmed COVID-19?" + "\r\n" + "IF YES - 7. Were you wearing recommended personal protective equipment?";
                        String questionsExit = "\r\n" + "1. Have you developed any symptoms that were referenced upon entry?";
                        // String cont = "\r\n" + "\r\n" + "SCREENER: " + mName.getText().toString();
                        //fileWriter.append(cont);
                        fileWriter.append(breaker);
                        fileWriter.append(keyEnter);
                        fileWriter.append(questionsEnter);
                        fileWriter.append(breaker);
                        fileWriter.append(keyExit);
                        fileWriter.append(questionsExit);
                        fileWriter.append(breaker);
                        fileWriter.close();
                        //Log.i("name", cont);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                mName.setVisibility(View.VISIBLE);
                key += 1;
                //mSupervisor.setVisibility(View.INVISIBLE);
                mName.setHint("Enter Name");
                mEnter.setVisibility(View.INVISIBLE);
                mExit.setVisibility(View.INVISIBLE);

                personleave = 1;
                person = 0;

                speak();
                counterExit = 0;
                mName.setOnEditorActionListener(new TextView.OnEditorActionListener() {

                    public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                        if (actionId == EditorInfo.IME_ACTION_DONE) {
                            String date = java.text.DateFormat.getDateTimeInstance().format(new Date());
//                            String contExit = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " EXITING:";
//                            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "RochesterManorScreening.txt");
//                            try {
//                                FileWriter fileWriter = new FileWriter(file, true);
//                                String cont = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " EXITING:";
//                                fileWriter.append(cont);
//                                fileWriter.close();
//                                Log.i("name", cont);
//                            } catch (FileNotFoundException e) {
//                                e.printStackTrace();
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }


                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    mName.setVisibility(View.INVISIBLE);
                                    String weird = "Have you developed any symptoms that were referenced upon entry?";
                                    text.setText(weird);
                                    Handler handler2 = new Handler();
                                    handler2.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            mTTS.speak("Have you developed any symptoms that were referenced upon entry?", TextToSpeech.QUEUE_FLUSH, null);
                                        }
                                    }, 0);

                                    Log.i("value", "how are you");
                                    Handler handler1 = new Handler();
                                    handler1.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            shom();
                                        }
                                    }, 2800);


                                }
                            }, 1000);

                        }
                        return false;
                    }
                });

                Log.e("value", "hello");

                mTemperature.setVisibility(View.INVISIBLE);
                mResult.setVisibility(View.INVISIBLE);


            }
        });


    }

//    public class DateChangedReceiver extends BroadcastReceiver {
//
//
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            Log.e("DateChangedReceiver", "Date changed");
//
//        }
//    }


    //create file


    //write to file


    public void shom() {
        //mName.setVisibility(View.INVISIBLE);
        //intent to show speech to text
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Please answer the question.");


        //start intent

        try {
            //if there was no error
            //show dialog

            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);

        } catch (Exception e) {
            //if there was some error
            //get message of error and show
            Toast.makeText(this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    //mEditText.getText().toString();

    private void speak() {
        String word = "Please use the handrub or wear the latex gloves. Next, type your name to sign this questionnaire. Click done on the keyboard when you're done.";
        text.setText(word);
        mTTS.speak("Please use the handrub or wear the latex gloves. Next, type your name to sign this questionnaire. Click done on the keyboard when you're done.", TextToSpeech.QUEUE_FLUSH, null);
        // TimeUnit.SECONDS.sleep(3);

        //shom();
    }


    protected void onDestroy() {

        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        super.onDestroy();
    }


    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1000:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission not granted!", Toast.LENGTH_SHORT).show();
                    finish();

                }
        }
    }


    // @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        counterEnter += 1;
        counterExit += 1;
       // mName.getText().clear();


        switch (requestCode) {
            case REQUEST_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    //get text array from voice intent
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);


                    Log.i("value", result.get(0).getClass().getName());


                    if (personleave == 1) {
                        if (counterExit == 1) {
                            if (result.get(0).contains("no") && result.get(0).length() <= 6) {
//
                                Log.i("value", "" + counterEnter);
                                String word3 = "Please check your temperature with the thermometer. Please click the temperature button after temperature scanning.";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Please check your temperature with the thermometer. Please click the temperature button after temperature scanning.", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

//                            mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException ie) {
                                    Thread.currentThread().interrupt();
                                }
                                mTemperature.postDelayed(new Runnable() {
                                    public void run() {
                                        mTemperature.setVisibility(View.VISIBLE);
                                    }
                                }, 0);
                                mTemperature.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        //mName.setVisibility(View.INVISIBLE);
                                        mTemp.setVisibility(View.VISIBLE);
                                        mTemp.setHint("Enter Temperature");
                                        String word = "Please type your temperature and click done on the keyboard when you are done.";
                                        text.setText(word);
                                        mTTS.speak(word, TextToSpeech.QUEUE_FLUSH, null);
                                        mTemperature.setVisibility(View.INVISIBLE);
                                        mTemp.setOnEditorActionListener(new TextView.OnEditorActionListener() {

                                            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                                                if (actionId == EditorInfo.IME_ACTION_DONE) {

                                                    float number = Float.parseFloat(mTemp.getText().toString());
                                                    if (number > 99.6) {
                                                        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                                                        try {
                                                            String temp = "[Temp:" + mTemp.getText().toString() + "] ";
                                                            String answer1 = " 1-NO ";
                                                            String contExit = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " EXITING:";
                                                            FileWriter fileWriter = new FileWriter(file, true);
                                                            String cont = "FAILED ";
                                                            fileWriter.append(contExit);
                                                            fileWriter.append(answer1);
                                                            fileWriter.append(temp);
                                                            fileWriter.append(cont);
                                                            fileWriter.close();
                                                            Log.i("name", cont);
                                                        } catch (FileNotFoundException e) {
                                                            e.printStackTrace();
                                                        } catch (IOException e) {
                                                            e.printStackTrace();
                                                        }
                                                        Handler handler = new Handler();
                                                        handler.postDelayed(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                mName.setVisibility(View.INVISIBLE);
                                                                mName.getText().clear();
                                                                String weird = "You may have COVID-19. Please leave.";
                                                                text.setText(weird);
                                                                Handler handler2 = new Handler();
                                                                handler2.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mTTS.speak("You may have COVID-19. Please leave!", TextToSpeech.QUEUE_FLUSH, null);
                                                                    }
                                                                }, 0);
                                                                mResult.setVisibility(View.VISIBLE);
                                                                mResult.setText("FAILED");
                                                                mResult.setTextColor(Color.parseColor("#e62400"));
                                                                Handler handler = new Handler();
                                                                handler.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mResult.setVisibility(View.INVISIBLE);
                                                                        text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                                        mEnter.setVisibility(View.VISIBLE);
                                                                        mExit.setVisibility(View.VISIBLE);
                                                                    }
                                                                }, 5000);

                                                            }
                                                        }, 1000);

                                                    } else if (number <= 99.6) {
//
                                                        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Passed.txt");
                                                        try {
                                                            String temp = "[Temp:" + mTemp.getText().toString() + "] ";
                                                            String answer1 = " 1-NO ";
                                                            String contExit = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " EXITING:";
                                                            FileWriter fileWriter = new FileWriter(file, true);
                                                            String cont = "PASSED ";
                                                            fileWriter.append(contExit);
                                                            fileWriter.append(answer1);
                                                            fileWriter.append(temp);
                                                            fileWriter.append(cont);
                                                            fileWriter.close();
                                                            Log.i("name", cont);
                                                        } catch (FileNotFoundException e) {
                                                            e.printStackTrace();
                                                        } catch (IOException e) {
                                                            e.printStackTrace();
                                                        }

                                                        Handler handler = new Handler();
                                                        handler.postDelayed(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                mName.setVisibility(View.INVISIBLE);
                                                                mName.getText().clear();
                                                                String weird = "You may exit! Have a nice day!";
                                                                text.setText(weird);
                                                                Handler handler2 = new Handler();
                                                                handler2.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mTTS.speak("You may exit! Have a nice day!", TextToSpeech.QUEUE_FLUSH, null);
                                                                    }
                                                                }, 0);
                                                                mResult.setVisibility(View.VISIBLE);
                                                                mResult.setText("PASSED");
                                                                mResult.setTextColor(Color.parseColor("#1800f0"));
                                                                Handler handler = new Handler();
                                                                handler.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mResult.setVisibility(View.INVISIBLE);
                                                                        text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                                        mEnter.setVisibility(View.VISIBLE);
                                                                        mExit.setVisibility(View.VISIBLE);
                                                                    }
                                                                }, 5000);

                                                            }
                                                        }, 1000);




                                                    }

                                                }
                                                return false;
                                            }
                                        });


                                    }

                                });


                            } else if (result.get(0).contains("yes") && result.get(0).length() <= 6) {

                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                                try {

                                    String answer1 = " 1-YES ";
                                    String contExit = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " EXITING:";
                                    FileWriter fileWriter = new FileWriter(file, true);
                                    String cont = "FAILED ";
                                    fileWriter.append(contExit);
                                    fileWriter.append(answer1);
                                    fileWriter.append(cont);
                                    fileWriter.close();
                                    Log.i("name", cont);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                               mName.setVisibility(View.INVISIBLE);
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        mName.getText().clear();
                                        String weird = "You may have COVID-19. Please leave.";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("You may have COVID-19. Please leave.", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        mResult.setVisibility(View.VISIBLE);
                                        mResult.setText("FAILED");
                                        mResult.setTextColor(Color.parseColor("#e62400"));
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mResult.setVisibility(View.INVISIBLE);
                                                text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                mEnter.setVisibility(View.VISIBLE);
                                                mExit.setVisibility(View.VISIBLE);
                                            }
                                        }, 5000);

                                    }
                                }, 1000);
                            } else {
                                String word3 = "Sorry, I could not understand. It will repeat the question.";
                                text.setText(word3);
                                mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);


                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        String weird = "Have you developed any symptoms that were referenced upon entry?";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("Have you developed any symptoms that were referenced upon entry?", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        counterExit = counterExit - 1;

                                        Log.i("value", "how are you");
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                shom();
                                            }
                                        }, 2700);


                                    }
                                }, 4000);
                            }


//
                        }

                    }















                    if (person == 1) {
                        if (counterEnter == 0) {
                            Log.i("value", "hi");
//

                        }//question 1
//
//
                        else if (counterEnter == 1) {
                            if (result.get(0).contains("no") && result.get(0).length() <= 6) {

                                Log.i("value", "" + counterEnter);
                                String word3 = "Do you have shortness of breath, chest tightness, or body aches?";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Do you have shortness of breath, chest tightness, or body aches?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

//                            try {
//                                Thread.sleep(2000);
//                            } catch (InterruptedException ie) {
//                                Thread.currentThread().interrupt();
//                            }
                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        shom();
                                    }
                                }, 2750);
//                            mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);
//                            try {
//                                Thread.sleep(1500);
//                            } catch (InterruptedException ie) {
//                                Thread.currentThread().interrupt();
//                            }
//                            shom();
                            } else if (result.get(0).contains("yes") && result.get(0).length() <= 6) {
//
                                String word3 = "Do you have any chronic conditions that may lead to these symptoms?";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Do you have any chronic conditions that may lead to these symptoms?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        counterEnter = 5;
                                        shom();
                                    }
                                }, 2500);

                            } else {
                                String word3 = "Sorry, I could not understand. It will repeat the question.";
                                text.setText(word3);
                                mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);


                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        String weird = "Do you have a fever, sore throat, cough, or a runny nose?";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("Do you have a fever, sore throat, cough, or a runny nose?", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        counterEnter = counterEnter - 1;

                                        Log.i("value", "how are you");
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                shom();
                                            }
                                        }, 2700);


                                    }
                                }, 4000);
                            }
                        }//question 4
                        else if (counterEnter == 6) {
                            if (result.get(0).contains("yes") && result.get(0).length() <= 6) {
                                Log.i("value", "" + counterEnter);
                                String word4 = "Do you have shortness of breath, chest tightness, or body aches?";
                                text.setText(word4);
                                Handler handler3 = new Handler();
                                handler3.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Do you have shortness of breath, chest tightness, or body aches?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

                                Handler handler4 = new Handler();
                                handler4.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        counterEnter = 1;
                                        shom();
                                    }
                                }, 2750);


                            } else if (result.get(0).contains("no") && result.get(0).length() <= 6) {
                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                                try {
                                    String answer1 = " 1-YES ";
                                    String contEnter = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
                                    FileWriter fileWriter = new FileWriter(file, true);
                                    String cont = "FAILED ";
                                    fileWriter.append(contEnter);
                                    fileWriter.append(answer1);
                                    fileWriter.append(cont);
                                    fileWriter.close();
                                    Log.i("name", cont);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        mName.getText().clear();
                                        String weird = "You may have COVID-19. Please leave.";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("You may have COVID-19. Please leave.", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);

                                        mResult.setVisibility(View.VISIBLE);
                                        mResult.setText("FAILED");
                                        mResult.setTextColor(Color.parseColor("#e62400"));
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mResult.setVisibility(View.INVISIBLE);
                                                text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                mEnter.setVisibility(View.VISIBLE);
                                                mExit.setVisibility(View.VISIBLE);
                                            }
                                        }, 5000);

                                    }
                                }, 1000);

                            }
                        } else if (counterEnter == 2) {
                            if (result.get(0).contains("no") && result.get(0).length() <= 6) {


                                Log.i("value", "" + counterEnter);
                                String word3 = "Do you have diarrhea, nausea, vomiting, or loss of taste and smell?";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Do you have diarrhea, nausea, vomiting, or loss of taste and smell?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        shom();
                                    }
                                }, 2800);
//                            mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);
//                            try {
//                                Thread.sleep(3000);
//                            } catch (InterruptedException ie) {
//                                Thread.currentThread().interrupt();
//                            }
//                            shom();
                            } else if (result.get(0).contains("yes") && result.get(0).length() <= 6) {
                                String word3 = "Do you have any chronic conditions that may lead to these symptoms?";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Do you have any chronic conditions that may lead to these symptoms?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        counterEnter = 6;
                                        //counterChronic = 1;
                                        shom();
                                    }
                                }, 2500);


                                //System.exit(0);
                            }
                            // mTextTv.setText(result.get(1));
                            // TimeUnit.SECONDS.sleep(3);
                            else {
                                String word3 = "Sorry, I could not understand. It will repeat the question.";
                                text.setText(word3);
                                mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);


                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        String weird = "Do you have shortness of breath, chest tightness, or body aches?";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("Do you have shortness of breath, chest tightness, or body aches?", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        counterEnter = counterEnter - 1;

                                        Log.i("value", "how are you");
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                shom();
                                            }
                                        }, 2750);


                                    }
                                }, 4000);
                            }
                        }//question 5
                        else if (counterEnter == 7) {
                            if (result.get(0).contains("yes") && result.get(0).length() <= 6) {


                                Log.i("value", "" + counterEnter);
                                String word4 = "Do you have diarrhea, nausea, vomiting, or loss of taste and smell?";
                                text.setText(word4);
                                Handler handler3 = new Handler();
                                handler3.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Do you have diarrhea, nausea, vomiting, or loss of taste and smell?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

                                Handler handler4 = new Handler();
                                handler4.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        counterEnter = 2;
                                        shom();
                                    }
                                }, 2750);


                            } else if (result.get(0).contains("no") && result.get(0).length() <= 6) {
                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                                try {
                                    String answer1 = " 1-NO ";
                                    String answer2 = " 2-YES ";
                                    String contEnter = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
                                    FileWriter fileWriter = new FileWriter(file, true);
                                    String cont = "FAILED ";
                                    fileWriter.append(contEnter);
                                    fileWriter.append(answer1);
                                    fileWriter.append(answer2);
                                    fileWriter.append(cont);
                                    fileWriter.close();
                                    Log.i("name", cont);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        mName.getText().clear();
                                        String weird = "You may have COVID-19. Please leave.";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("You may have COVID-19. Please leave.", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);

                                        mResult.setVisibility(View.VISIBLE);
                                        mResult.setText("FAILED");
                                        mResult.setTextColor(Color.parseColor("#e62400"));
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mResult.setVisibility(View.INVISIBLE);
                                                text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                mEnter.setVisibility(View.VISIBLE);
                                                mExit.setVisibility(View.VISIBLE);
                                            }
                                        }, 5000);

                                    }
                                }, 1000);
                            }
                        } else if (counterEnter == 3) {
                            if (result.get(0).contains("no") && result.get(0).length() <= 6) {
//                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "RochesterManorScreening.txt");
//                                try {
//                                    FileWriter fileWriter = new FileWriter(file, true);
//                                    String cont = " 3-NO ";
//                                    fileWriter.append(cont);
//                                    fileWriter.close();
//                                    Log.i("name", cont);
//                                } catch (FileNotFoundException e) {
//                                    e.printStackTrace();
//                                } catch (IOException e) {
//                                    e.printStackTrace();
//                                }

                                Log.i("value", "" + counterEnter);
                                String word3 = "Please check your temperature with the thermometer. Please click the temperature button after temperature scanning.";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Please check your temperature with the thermometer. Please click the temperature button after temperature scanning.", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

//                            mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException ie) {
                                    Thread.currentThread().interrupt();
                                }
                                mTemperature.postDelayed(new Runnable() {
                                    public void run() {
                                        mTemperature.setVisibility(View.VISIBLE);
                                    }
                                }, 0);
                                mTemperature.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mName.setVisibility(View.INVISIBLE);
                                        mTemp.setVisibility(View.VISIBLE);
                                        mName.setHint("Enter Temperature");
                                        String word = "Please type your temperature and click done on the keyboard when you are done.";
                                        text.setText(word);
                                        mTTS.speak(word, TextToSpeech.QUEUE_FLUSH, null);
                                        mTemperature.setVisibility(View.INVISIBLE);
                                        mTemp.setOnEditorActionListener(new TextView.OnEditorActionListener() {

                                            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                                                if (actionId == EditorInfo.IME_ACTION_DONE) {

                                                    float number = Float.parseFloat(mTemp.getText().toString());
                                                    if (number > 99.6) {
                                                        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                                                        try {
                                                            String temp = "[Temp:" + mTemp.getText().toString() + "] ";
                                                            String answer1 = " 1-NO ";
                                                            String answer2 = " 2-NO";
                                                            String answer3 = " 3-NO";
                                                            String contExit = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " EXITING:";
                                                            FileWriter fileWriter = new FileWriter(file, true);
                                                            String cont = "FAILED ";
                                                            fileWriter.append(contExit);
                                                            fileWriter.append(answer1);
                                                            fileWriter.append(answer2);
                                                            fileWriter.append(answer3);
                                                            fileWriter.append(temp);
                                                            fileWriter.append(cont);
                                                            fileWriter.close();
                                                            Log.i("name", cont);
                                                        } catch (FileNotFoundException e) {
                                                            e.printStackTrace();
                                                        } catch (IOException e) {
                                                            e.printStackTrace();
                                                        }
                                                        Handler handler = new Handler();
                                                        handler.postDelayed(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                mTemp.setVisibility(View.INVISIBLE);
                                                                mTemp.getText().clear();
                                                                mName.setVisibility(View.INVISIBLE);
                                                                mName.getText().clear();
                                                                String weird = "You may have COVID-19. Please leave.";
                                                                text.setText(weird);
                                                                Handler handler2 = new Handler();
                                                                handler2.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mTTS.speak("You may have COVID-19. Please leave!", TextToSpeech.QUEUE_FLUSH, null);
                                                                    }
                                                                }, 0);
                                                                mResult.setVisibility(View.VISIBLE);
                                                                mResult.setText("FAILED");
                                                                mResult.setTextColor(Color.parseColor("#e62400"));
                                                                Handler handler = new Handler();
                                                                handler.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mResult.setVisibility(View.INVISIBLE);
                                                                        text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                                        mEnter.setVisibility(View.VISIBLE);
                                                                        mExit.setVisibility(View.VISIBLE);
                                                                    }
                                                                }, 5000);

                                                            }
                                                        }, 1000);

                                                    } else if (number <= 99.6) {
                                                        Handler handler = new Handler();
                                                        handler.postDelayed(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                mTemp.setVisibility(View.INVISIBLE);
                                                                mName.setVisibility(View.INVISIBLE);
                                                                String weird = "Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?";
                                                                text.setText(weird);
                                                                Handler handler2 = new Handler();
                                                                handler2.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mTTS.speak("Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?", TextToSpeech.QUEUE_FLUSH, null);
                                                                    }
                                                                }, 0);

                                                                Log.i("value", "how are you");
                                                                Handler handler1 = new Handler();
                                                                handler1.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        shom();
                                                                    }
                                                                }, 6100);


                                                            }
                                                        }, 1000);
                                                    } else {
                                                        Log.i("value", "name");
                                                    }

                                                }
                                                return false;
                                            }
                                        });


                                    }

                                });


                            } else if (result.get(0).contains("yes") && result.get(0).length() <= 6) {

                                String word3 = "Do you have any chronic conditions that may lead to these symptoms?";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Do you have any chronic conditions that may lead to these symptoms?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        counterEnter = 7;
                                        //counterChronic = 1;
                                        shom();
                                    }
                                }, 2500);
                            }


                            // mTextTv.setText(result.get(1));
                            // TimeUnit.SECONDS.sleep(3);
                            else {
                                String word3 = "Sorry, I could not understand. It will repeat the question.";
                                text.setText(word3);
                                mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);


                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        String weird = "Do you have diarrhea, nausea, vomiting, or loss of taste and smell?";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("Do you have diarrhea, nausea, vomiting, or loss of taste and smell?", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        counterEnter = counterEnter - 1;

                                        Log.i("value", "how are you");
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                shom();
                                            }
                                        }, 2800);


                                    }
                                }, 4000);
                            }
                        }//question 11
                        else if (counterEnter == 8) {
                            if (result.get(0).contains("yes") && result.get(0).length() <= 6) {

                                Log.i("value", "" + counterEnter);
                                String word3 = "Please check your temperature with the thermometer. Please click the temperature button after temperature scanning.";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Please check your temperature with the thermometer. Please click the temperature button after temperature scanning.", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

//                            mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException ie) {
                                    Thread.currentThread().interrupt();
                                }
                                mTemperature.postDelayed(new Runnable() {
                                    public void run() {
                                        mTemperature.setVisibility(View.VISIBLE);
                                    }
                                }, 0);
                                mTemperature.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mTemp.setVisibility(View.VISIBLE);
                                        mName.setHint("Enter Temperature");
                                        String word = "Please type your temperature and click done on the keyboard when you are done.";
                                        text.setText(word);
                                        mTTS.speak(word, TextToSpeech.QUEUE_FLUSH, null);
                                        mTemperature.setVisibility(View.INVISIBLE);
                                        mTemp.setOnEditorActionListener(new TextView.OnEditorActionListener() {

                                            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                                                if (actionId == EditorInfo.IME_ACTION_DONE) {
                                                    float number = Float.parseFloat(mTemp.getText().toString());
                                                    if (number > 99.6) {
                                                        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                                                        try {
                                                            String temp = " [Temp:" + mTemp.getText().toString() + "] ";
                                                            String answer1 = " 1-NO ";
                                                            String answer2 = " 2-NO ";
                                                            String answer3 = " 3-NO ";
                                                            String contExit = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
                                                            FileWriter fileWriter = new FileWriter(file, true);
                                                            String cont = "FAILED ";
                                                            fileWriter.append(contExit);
                                                            fileWriter.append(answer1);
                                                            fileWriter.append(answer2);
                                                            fileWriter.append(answer3);
                                                            fileWriter.append(temp);
                                                            fileWriter.append(cont);
                                                            fileWriter.close();
                                                            Log.i("name", cont);
                                                        } catch (FileNotFoundException e) {
                                                            e.printStackTrace();
                                                        } catch (IOException e) {
                                                            e.printStackTrace();
                                                        }
                                                        Handler handler = new Handler();
                                                        handler.postDelayed(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                mName.setVisibility(View.INVISIBLE);
                                                                mTemp.setVisibility(View.INVISIBLE);
                                                                mTemp.getText().clear();
                                                                mName.getText().clear();
                                                                String weird = "You may have COVID-19. Please leave.";
                                                                text.setText(weird);
                                                                Handler handler2 = new Handler();
                                                                handler2.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mTTS.speak("You may have COVID-19. Please leave!", TextToSpeech.QUEUE_FLUSH, null);
                                                                    }
                                                                }, 0);
                                                                mResult.setVisibility(View.VISIBLE);
                                                                mResult.setText("FAILED");
                                                                mResult.setTextColor(Color.parseColor("#e62400"));
                                                                Handler handler = new Handler();
                                                                handler.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mResult.setVisibility(View.INVISIBLE);
                                                                        text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                                        mEnter.setVisibility(View.VISIBLE);
                                                                        mExit.setVisibility(View.VISIBLE);
                                                                    }
                                                                }, 5000);

                                                            }
                                                        }, 1000);

//
                                                    } else if (number <= 99.6) {


                                                        Handler handler = new Handler();
                                                        handler.postDelayed(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                mName.setVisibility(View.INVISIBLE);
                                                                mTemp.setVisibility(View.INVISIBLE);
                                                                String weird = "Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?";
                                                                text.setText(weird);
                                                                Handler handler2 = new Handler();
                                                                handler2.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        mTTS.speak("Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?", TextToSpeech.QUEUE_FLUSH, null);
                                                                    }
                                                                }, 0);

                                                                Log.i("value", "how are you");
                                                                Handler handler1 = new Handler();
                                                                handler1.postDelayed(new Runnable() {
                                                                    @Override
                                                                    public void run() {
                                                                        counterEnter = 3;
                                                                        shom();
                                                                    }
                                                                }, 6100);


                                                            }
                                                        }, 1000);
                                                    }

                                                }
                                                return false;
                                            }
                                        });


                                    }

                                });


                            } else if (result.get(0).contains("no") && result.get(0).length() <= 6) {
                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                                try {
                                   // String temp = " [Temp:" + mTemp.getText().toString() + "] ";
                                    String answer1 = " 1-NO ";
                                    String answer2 = " 2-NO ";
                                    String answer3 = " 3-YES ";
                                    String contExit = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
                                    FileWriter fileWriter = new FileWriter(file, true);
                                    String cont = "FAILED ";
                                    fileWriter.append(contExit);
                                    fileWriter.append(answer1);
                                    fileWriter.append(answer2);
                                    fileWriter.append(answer3);
                                    //fileWriter.append(temp);
                                    fileWriter.append(cont);
                                    fileWriter.close();
                                    Log.i("name", cont);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        mName.getText().clear();
                                        String weird = "You may have COVID-19. Please leave.";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("You may have COVID-19. Please leave!", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        mResult.setVisibility(View.VISIBLE);
                                        mResult.setText("FAILED");
                                        mResult.setTextColor(Color.parseColor("#e62400"));
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mResult.setVisibility(View.INVISIBLE);
                                                text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                mEnter.setVisibility(View.VISIBLE);
                                                mExit.setVisibility(View.VISIBLE);
                                            }
                                        }, 5000);

                                    }
                                }, 1000);
                            }
                        } else if (counterEnter == 4) { //13
                            if (result.get(0).contains("yes") && result.get(0).length() <= 6) {
                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                                try {
                                    String temp = " [Temp:" + mTemp.getText().toString() + "] ";
                                    String answer1 = " 1-NO ";
                                    String answer2 = " 2-NO ";
                                    String answer3 = " 3-NO ";
                                    String answer4 = " 4-YES ";
                                    String contEnter = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
                                    FileWriter fileWriter = new FileWriter(file, true);
                                    String cont = "FAILED ";
                                    fileWriter.append(contEnter);
                                    fileWriter.append(answer1);
                                    fileWriter.append(answer2);
                                    fileWriter.append(answer3);
                                    fileWriter.append(temp);
                                    fileWriter.append(answer4);
                                    fileWriter.append(cont);
                                    fileWriter.close();
                                    Log.i("name", cont);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        mName.getText().clear();
                                        String weird = "You may have COVID-19. Please leave.";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("You may have COVID-19. Please leave.", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);

                                        mResult.setVisibility(View.VISIBLE);
                                        mResult.setText("FAILED");
                                        mResult.setTextColor(Color.parseColor("#e62400"));
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mResult.setVisibility(View.INVISIBLE);
                                                text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                mEnter.setVisibility(View.VISIBLE);
                                                mExit.setVisibility(View.VISIBLE);
                                            }
                                        }, 5000);

                                    }
                                }, 1000);




                            } else if (result.get(0).contains("no") && result.get(0).length() <= 6) {

                                String word3 = "Have you worked in facilities or offices with recognized COVID-19 cases?";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Have you worked in facilities or offices with recognized COVID-19 cases?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        counterEnter = 8;
                                        //counterChronic = 1;
                                        shom();
                                    }
                                }, 3400);
//
                            }
                            // mTextTv.setText(result.get(1));
                            // TimeUnit.SECONDS.sleep(3);
                            else {
                                String word3 = "Sorry, I could not understand. It will repeat the question.";
                                text.setText(word3);
                                mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);


                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        String weird = "Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("Have you had contact for more than 10 minutes with someone who is suspected or confirmed COVID-19 positive or is awaiting test results?", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        counterEnter = counterEnter - 1;

                                        Log.i("value", "how are you");
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                shom();
                                            }
                                        }, 6100);


                                    }
                                }, 4000);
                            }
                        } else if (counterEnter == 9) {
                            if (result.get(0).contains("yes") && result.get(0).length() <= 6) {


                                Log.i("value", "" + counterEnter);
                                String word4 = "Did you have greater than 10 minutes of contact with a person with confirmed COVID-19?";
                                text.setText(word4);
                                Handler handler3 = new Handler();
                                handler3.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Did you have greater than 10 minutes of contact with a person with confirmed COVID-19?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

                                Handler handler4 = new Handler();
                                handler4.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        counterEnter = 4;
                                        shom();
                                    }
                                }, 3500);


                            } else if (result.get(0).contains("no") && result.get(0).length() <= 6) {
                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Passed.txt");
                                try {
                                    String temp = " [Temp:" + mTemp.getText().toString() + "] ";
                                    String answer1 = " 1-NO ";
                                    String answer2 = " 2-NO ";
                                    String answer3 = " 3-NO ";
                                    String answer4 = " 4-NO ";
                                    String answer5 = " 5-NO ";
                                    String contEnter = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
                                    FileWriter fileWriter = new FileWriter(file, true);
                                    String cont = "PASSED ";
                                    fileWriter.append(contEnter);
                                    fileWriter.append(answer1);
                                    fileWriter.append(answer2);
                                    fileWriter.append(answer3);
                                    fileWriter.append(temp);
                                    fileWriter.append(answer4);
                                    fileWriter.append(answer5);
                                    fileWriter.append(cont);
                                    fileWriter.close();
                                    Log.i("name", cont);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        mName.getText().clear();
                                        String weird = "You may enter! Have a nice day!";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("You may enter! Have a nice day!", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);

                                        mResult.setVisibility(View.VISIBLE);
                                        mResult.setText("PASSED");
                                        mResult.setTextColor(Color.parseColor("#1800f0"));
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mResult.setVisibility(View.INVISIBLE);
                                                text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                mEnter.setVisibility(View.VISIBLE);
                                                mExit.setVisibility(View.VISIBLE);
                                            }
                                        }, 5000);

                                    }
                                }, 1000);

                            }
                            else {
                                String word3 = "Sorry, I could not understand. It will repeat the question.";
                                text.setText(word3);
                                mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);


                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        String weird = "Have you worked in facilities or offices with recognized COVID-19 cases?";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("Have you worked in facilities or offices with recognized COVID-19 cases?", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        counterEnter = counterEnter - 1;

                                        Log.i("value", "how are you");
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                shom();
                                            }
                                        }, 3400);


                                    }
                                }, 4000);
                            }
                        } else if (counterEnter == 5) {
                            if (result.get(0).contains("yes") && result.get(0).length() <= 6) {
//                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "RochesterManorScreening.txt");
//                                try {
//                                    FileWriter fileWriter = new FileWriter(file, true);
//                                    String cont = " 6-YES ";
//                                    fileWriter.append(cont);
//                                    fileWriter.close();
//                                    Log.i("name", cont);
//                                } catch (FileNotFoundException e) {
//                                    e.printStackTrace();
//                                } catch (IOException e) {
//                                    e.printStackTrace();
//                                }
                                String word3 = "Were you wearing recommended personal protective equipment?";
                                text.setText(word3);
                                Handler handler2 = new Handler();
                                handler2.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mTTS.speak("Were you wearing recommended personal protective equipment?", TextToSpeech.QUEUE_FLUSH, null);
                                    }
                                }, 0);

                                Handler handler1 = new Handler();
                                handler1.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        counterEnter = 9;
                                        //counterChronic = 1;
                                        shom();
                                    }
                                }, 2400);


                            } else if (result.get(0).contains("no") && result.get(0).length() <= 6) {
                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Passed.txt");
                                try {
                                    String temp = " [Temp:" + mTemp.getText().toString() + "] ";
                                    String answer1 = " 1-NO ";
                                    String answer2 = " 2-NO ";
                                    String answer3 = " 3-NO ";
                                    String answer4 = " 4-NO ";
                                    String answer5 = " 5-YES ";
                                    String answer6 = " 6-NO ";
                                    String contEnter = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
                                    FileWriter fileWriter = new FileWriter(file, true);
                                    String cont = "PASSED ";
                                    fileWriter.append(contEnter);
                                    fileWriter.append(answer1);
                                    fileWriter.append(answer2);
                                    fileWriter.append(answer3);
                                    fileWriter.append(temp);
                                    fileWriter.append(answer4);
                                    fileWriter.append(answer5);
                                    fileWriter.append(answer6);
                                    fileWriter.append(cont);
                                    fileWriter.close();
                                    Log.i("name", cont);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        mName.getText().clear();
                                        String weird = "You may enter! Have a nice day!";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("You may enter! Have a nice day!", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);

                                        mResult.setVisibility(View.VISIBLE);
                                        mResult.setText("PASSED");
                                        mResult.setTextColor(Color.parseColor("#1800f0"));
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mResult.setVisibility(View.INVISIBLE);
                                                text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                mEnter.setVisibility(View.VISIBLE);
                                                mExit.setVisibility(View.VISIBLE);
                                            }
                                        }, 5000);

                                    }
                                }, 1000);


                            }
                            // mTextTv.setText(result.get(1));
                            // TimeUnit.SECONDS.sleep(3);
                            else {
                                String word3 = "Sorry, I could not understand. It will repeat the question.";
                                text.setText(word3);
                                mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);


                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        String weird = "Did you have greater than 10 minutes of contact with a person with confirmed COVID-19?";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("Did you have greater than 10 minutes of contact with a person with confirmed COVID-19?", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        counterEnter = counterEnter - 1;

                                        Log.i("value", "how are you");
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                shom();
                                            }
                                        }, 3500);


                                    }
                                }, 4000);
                            }
                        } else if (counterEnter == 10) {
                            if (result.get(0).contains("yes") && result.get(0).length() <= 6) {
                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Passed.txt");
                                try {
                                    String temp = " [Temp:" + mTemp.getText().toString() + "] ";
                                    String answer1 = " 1-NO ";
                                    String answer2 = " 2-NO ";
                                    String answer3 = " 3-NO ";
                                    String answer4 = " 4-NO ";
                                    String answer5 = " 5-YES ";
                                    String answer6 = " 6-YES ";
                                    String answer7 = " 7-YES ";
                                    String contEnter = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
                                    FileWriter fileWriter = new FileWriter(file, true);
                                    String cont = "PASSED ";
                                    fileWriter.append(contEnter);
                                    fileWriter.append(answer1);
                                    fileWriter.append(answer2);
                                    fileWriter.append(answer3);
                                    fileWriter.append(temp);
                                    fileWriter.append(answer4);
                                    fileWriter.append(answer5);
                                    fileWriter.append(answer6);
                                    fileWriter.append(answer7);
                                    fileWriter.append(cont);
                                    fileWriter.close();
                                    Log.i("name", cont);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        mName.getText().clear();
                                        String weird = "You may enter! Have a nice day!";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("You may enter! Have a nice day!", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);

                                        mResult.setVisibility(View.VISIBLE);
                                        mResult.setText("PASSED");
                                        mResult.setTextColor(Color.parseColor("#1800f0"));
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mResult.setVisibility(View.INVISIBLE);
                                                text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                mEnter.setVisibility(View.VISIBLE);
                                                mExit.setVisibility(View.VISIBLE);
                                            }
                                        }, 5000);

                                    }
                                }, 1000);


                            } else if (result.get(0).contains("no") && result.get(0).length() <= 6) {
                                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "Failed.txt");
                                try {
                                    String temp = " [Temp:" + mTemp.getText().toString() + "] ";
                                    String answer1 = " 1-NO ";
                                    String answer2 = " 2-NO ";
                                    String answer3 = " 3-NO ";
                                    String answer4 = " 4-NO ";
                                    String answer5 = " 5-YES ";
                                    String answer6 = " 6-YES ";
                                    String answer7 = " 7-NO ";
                                    String contEnter = "\r\n" + "[" + date + "] " + " " + mName.getText().toString() + " ENTERING:";
                                    FileWriter fileWriter = new FileWriter(file, true);
                                    String cont = "FAILED ";
                                    fileWriter.append(contEnter);
                                    fileWriter.append(answer1);
                                    fileWriter.append(answer2);
                                    fileWriter.append(answer3);
                                    fileWriter.append(temp);
                                    fileWriter.append(answer4);
                                    fileWriter.append(answer5);
                                    fileWriter.append(answer6);
                                    fileWriter.append(answer7);
                                    fileWriter.append(cont);
                                    fileWriter.close();
                                    Log.i("name", cont);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        mName.getText().clear();
                                        String weird = "You may have COVID-19. Please leave.";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("You may have COVID-19. Please leave.", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);

                                        mResult.setVisibility(View.VISIBLE);
                                        mResult.setText("FAILED");
                                        mResult.setTextColor(Color.parseColor("#e62400"));
                                        Handler handler = new Handler();
                                        handler.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mResult.setVisibility(View.INVISIBLE);
                                                text.setText("Click the start button. \r\nOnly answer after the prompt pops up. \r\nYou must answer yes or no for all questions. \r\nSpeak yes to begin.");
                                                mEnter.setVisibility(View.VISIBLE);
                                                mExit.setVisibility(View.VISIBLE);
                                            }
                                        }, 5000);

                                    }
                                }, 1000);

                            } else {
                                String word3 = "Sorry, I could not understand. It will repeat the question.";
                                text.setText(word3);
                                mTTS.speak(word3, TextToSpeech.QUEUE_FLUSH, null);


                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mName.setVisibility(View.INVISIBLE);
                                        String weird = "Were you wearing recommended personal protective equipment?";
                                        text.setText(weird);
                                        Handler handler2 = new Handler();
                                        handler2.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                mTTS.speak("Were you wearing recommended personal protective equipment?", TextToSpeech.QUEUE_FLUSH, null);
                                            }
                                        }, 0);
                                        counterEnter = counterEnter - 1;

                                        Log.i("value", "how are you");
                                        Handler handler1 = new Handler();
                                        handler1.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                shom();
                                            }
                                        }, 2400);


                                    }
                                }, 4000);
                            }
                        }
                        //question 14


                        else {
                            break;
                        }

                    }

                }
                break;

            }


        }

    }
}
